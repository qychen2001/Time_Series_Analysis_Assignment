y<-array(0,dim=100)
e<-rnorm(101)
for(i in 1:100){
  y[i+1]<-(e[i]+e[i+1])/2
  }
y<-ts(y[1:100])
plot(y)